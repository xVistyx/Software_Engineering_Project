const contentElements = new Map();
const evaluatedContent = new Set();

let updateTimer = null;
let currentlySending = false;


/*
|--------------------------------------------------------------------------
| Helpers
|--------------------------------------------------------------------------
*/

function getVideoId(url) {
    try {
        const parsedUrl = new URL(url);
        return parsedUrl.searchParams.get("v");
    } catch {
        return null;
    }
}


function cleanText(element) {
    return element?.textContent?.trim() ?? "";
}


/*
|--------------------------------------------------------------------------
| Primary YouTube content
|--------------------------------------------------------------------------
|
| This is the video the user intentionally opened.
|
*/

function getPrimaryContent() {
    // Only treat /watch pages as having primary video content.
    if (!window.location.pathname.startsWith("/watch")) {
        return null;
    }

    const videoId = getVideoId(window.location.href);

    if (!videoId) {
        return null;
    }

    const titleElement = document.querySelector(
        "ytd-watch-metadata h1 yt-formatted-string"
    );

    const channelElement = document.querySelector(
        "ytd-watch-metadata #channel-name a"
    );

    return {
        content_id: videoId,
        source: "youtube",
        content_type: "video",
        title: cleanText(titleElement),
        url: window.location.href,
        channel: cleanText(channelElement)
    };
}


/*
|--------------------------------------------------------------------------
| Recommended YouTube content
|--------------------------------------------------------------------------
|
| Finds individual recommended videos.
|
*/

function getRecommendedContent() {
    const content = [];

    /*
     * Sidebar recommendations on a watch page.
     */
    const sidebarCards = document.querySelectorAll(
        "ytd-compact-video-renderer"
    );

    sidebarCards.forEach(card => {
        processRecommendationCard(card, content);
    });


    /*
     * Homepage / search-style cards.
     *
     * This makes the script work on more than just /watch.
     */
    const richCards = document.querySelectorAll(
        "ytd-rich-item-renderer"
    );

    richCards.forEach(card => {
        processRecommendationCard(card, content);
    });


    return content;
}


function processRecommendationCard(card, content) {
    const titleElement = card.querySelector("#video-title");

    const linkElement =
        card.querySelector("a#thumbnail") ??
        card.querySelector("a[href*='/watch?v=']");

    if (!titleElement || !linkElement) {
        return;
    }

    const url = linkElement.href;

    if (!url) {
        return;
    }

    const videoId = getVideoId(url);

    if (!videoId) {
        return;
    }

    /*
     * Prevent duplicates.
     */
    if (
        content.some(
            item => item.content_id === videoId
        )
    ) {
        return;
    }

    const channelElement =
        card.querySelector("#channel-name") ??
        card.querySelector(
            "ytd-channel-name"
        );

    /*
     * Save connection between backend ID
     * and actual YouTube HTML element.
     */
    contentElements.set(videoId, card);

    /*
     * If backend already evaluated this video,
     * don't send it again.
     */
    if (evaluatedContent.has(videoId)) {
        return;
    }

    content.push({
        content_id: videoId,
        source: "youtube",
        content_type: "video",
        title: cleanText(titleElement),
        url: url,
        channel: cleanText(channelElement)
    });
}


/*
|--------------------------------------------------------------------------
| Build payload
|--------------------------------------------------------------------------
*/

function collectYouTubeContent() {
    const primaryContent =
        getPrimaryContent();

    const recommendedContent =
        getRecommendedContent();

    return {
        page_type:
            primaryContent
                ? "youtube_watch"
                : "youtube_feed",

        primary_content:
            primaryContent,

        recommended_content:
            recommendedContent
    };
}


/*
|--------------------------------------------------------------------------
| Send to background.js
|--------------------------------------------------------------------------
*/

async function sendYouTubeContent() {
    if (currentlySending) {
        return;
    }

    const payload =
        collectYouTubeContent();

    /*
     * Nothing new to evaluate.
     */
    if (
        !payload.primary_content &&
        payload.recommended_content.length === 0
    ) {
        return;
    }

    /*
     * Don't continuously send the same
     * primary video.
     */
    if (
        payload.primary_content &&
        evaluatedContent.has(
            payload.primary_content.content_id
        )
    ) {
        payload.primary_content = null;
    }

    if (
        !payload.primary_content &&
        payload.recommended_content.length === 0
    ) {
        return;
    }

    currentlySending = true;

    try {
        const response =
            await chrome.runtime.sendMessage({
                type: "DYNAMIC_CONTENT",
                payload: payload
            });

        if (!response) {
            console.warn(
                "No dynamic-content response received."
            );
            return;
        }

        if (response.error) {
            console.error(
                "Dynamic content backend error:",
                response.error
            );
            return;
        }

        applyEvaluationResults(response);

    } catch (error) {
        console.error(
            "Could not evaluate YouTube content:",
            error
        );
    } finally {
        currentlySending = false;
    }
}


/*
|--------------------------------------------------------------------------
| Apply backend results
|--------------------------------------------------------------------------
*/

function applyEvaluationResults(response) {
    /*
     * Primary video
     */
    if (response.primary_content) {
        evaluatedContent.add(
            response.primary_content.content_id
        );

        /*
         * You can decide later what to do if
         * the actual video itself should be blocked.
         *
         * For now we're only blurring recommendations.
         */
    }


    /*
     * Recommended videos
     */
    const recommendations =
        response.recommended_content ?? [];

    recommendations.forEach(result => {
        const contentId =
            result.content_id;

        evaluatedContent.add(contentId);

        const element =
            contentElements.get(contentId);

        if (!element) {
            return;
        }

        applyAction(
            element,
            result.action
        );
    });
}


function applyAction(element, action) {
    /*
     * Always clear previous state first.
     */
    element.classList.remove(
        "lockdown-blurred",
        "lockdown-hidden"
    );

    switch (action) {
        case "blur":
            element.classList.add(
                "lockdown-blurred"
            );
            break;

        case "hide":
            element.classList.add(
                "lockdown-hidden"
            );
            break;

        case "allow":
        default:
            break;
    }
}


/*
|--------------------------------------------------------------------------
| Inject CSS
|--------------------------------------------------------------------------
*/

function injectStyles() {
    if (
        document.getElementById(
            "lockdown-dynamic-styles"
        )
    ) {
        return;
    }

    const style =
        document.createElement("style");

    style.id =
        "lockdown-dynamic-styles";

    style.textContent = `
        .lockdown-blurred {
            filter: blur(12px) !important;
            opacity: 0.35 !important;
            transition: filter 0.2s ease,
                        opacity 0.2s ease;
        }

        .lockdown-hidden {
            display: none !important;
        }
    `;

    document.head.appendChild(style);
}


/*
|--------------------------------------------------------------------------
| Handle YouTube's dynamic loading
|--------------------------------------------------------------------------
*/

function observeYouTube() {
    const observer =
        new MutationObserver(() => {

            clearTimeout(updateTimer);

            /*
             * Debounce because YouTube causes
             * lots of DOM mutations.
             */
            updateTimer = setTimeout(() => {
                sendYouTubeContent();
            }, 500);
        });

    observer.observe(
        document.body,
        {
            childList: true,
            subtree: true
        }
    );
}


/*
|--------------------------------------------------------------------------
| Detect SPA navigation
|--------------------------------------------------------------------------
|
| YouTube changes URLs without always reloading
| the whole page.
|
*/

let lastUrl = window.location.href;

function watchUrlChanges() {
    setInterval(() => {
        if (
            window.location.href === lastUrl
        ) {
            return;
        }

        lastUrl =
            window.location.href;

        /*
         * Primary video changed, so allow it
         * to be evaluated again.
         */
        setTimeout(() => {
            sendYouTubeContent();
        }, 500);

    }, 500);
}


/*
|--------------------------------------------------------------------------
| Start
|--------------------------------------------------------------------------
*/

function start() {
    injectStyles();

    sendYouTubeContent();

    observeYouTube();

    watchUrlChanges();
}


start();